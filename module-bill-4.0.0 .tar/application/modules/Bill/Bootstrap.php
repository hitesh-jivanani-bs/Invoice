<?php

class Bill_Bootstrap extends Engine_Application_Bootstrap_Abstract
{

}