

<?php

class Bill_Model_Bill extends Core_Model_Item_Abstract
{



 


}
	?>