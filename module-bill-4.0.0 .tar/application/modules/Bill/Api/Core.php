<?php 

class Bill_Api_Core extends Core_Api_Abstract
{
  
}

?>