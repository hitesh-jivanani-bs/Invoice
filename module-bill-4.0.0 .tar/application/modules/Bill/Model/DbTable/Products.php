<?php

class Bill_Model_DbTable_Products extends Core_Model_Item_DbTable_Abstract
{
    protected $_rowClass = "Bill_Model_Products";
}